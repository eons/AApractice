import{cj as a,ck as r,aM as s,R as t}from"./entry.7198d58c.js";const u=a(()=>{{const{isFailure:e}=r();return e!=null&&e.value?s(t.Dashboard):null}});export{u as default};
