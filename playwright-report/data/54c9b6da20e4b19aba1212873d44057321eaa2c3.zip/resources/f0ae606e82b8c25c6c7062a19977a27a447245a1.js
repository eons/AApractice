import{cj as l,av as i}from"./entry.7198d58c.js";const n=l((a,e)=>{if(a.fullPath===e.fullPath){const t=i();return location.href=t.variables.value.BASE_URL+"/"}});export{n as default};
