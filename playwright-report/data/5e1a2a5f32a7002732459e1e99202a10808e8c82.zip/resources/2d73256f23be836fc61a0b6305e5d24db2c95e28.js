const o=""+new URL("logo-full-dark.f1c6e7a4.svg",import.meta.url).href;export{o as _};
