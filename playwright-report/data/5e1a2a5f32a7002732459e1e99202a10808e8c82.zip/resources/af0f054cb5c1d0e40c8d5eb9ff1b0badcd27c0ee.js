import{ch as a,ci as r,aM as s,R as t}from"./entry.14fc4fa6.js";const u=a(()=>{{const{isFailure:e}=r();return e!=null&&e.value?s(t.Dashboard):null}});export{u as default};
