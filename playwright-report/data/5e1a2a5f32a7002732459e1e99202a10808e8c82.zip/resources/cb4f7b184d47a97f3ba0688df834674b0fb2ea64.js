import{ch as l,av as i}from"./entry.14fc4fa6.js";const n=l((a,e)=>{if(a.fullPath===e.fullPath){const t=i();return location.href=t.variables.value.BASE_URL+"/"}});export{n as default};
