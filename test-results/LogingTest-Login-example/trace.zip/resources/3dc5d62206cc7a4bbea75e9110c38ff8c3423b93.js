import{c4 as a,c5 as r,a_ as s,R as t}from"./entry.82f60fbf.js";const u=a(()=>{{const{isFailure:e}=r();return e!=null&&e.value?s(t.Dashboard):null}});export{u as default};
