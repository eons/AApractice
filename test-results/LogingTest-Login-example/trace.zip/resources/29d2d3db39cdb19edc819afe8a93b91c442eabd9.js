import{c4 as l,aM as i}from"./entry.82f60fbf.js";const n=l((a,e)=>{if(a.fullPath===e.fullPath){const t=i();return location.href=t.variables.value.BASE_URL+"/"}});export{n as default};
